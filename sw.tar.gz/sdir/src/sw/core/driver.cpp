// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2019-2020 Egor Pugin <egor.pugin@gmail.com>

#include "driver.h"

namespace sw
{

IDriver::~IDriver()
{
}

} // namespace sw
